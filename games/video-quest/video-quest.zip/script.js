/* =====================================================
   VIDEO QUEST - SCRIPT.JS
===================================================== */


/* =====================================================
   SCREEN ELEMENTS
===================================================== */

const welcomeScreen = document.getElementById("welcomeScreen");
const levelScreen = document.getElementById("levelScreen");
const videoSelectScreen = document.getElementById("videoSelectScreen");
const lessonScreen = document.getElementById("lessonScreen");


/* =====================================================
   SCREEN HISTORY
===================================================== */

let screenHistory = [];


/* =====================================================
   SHOW SCREEN
===================================================== */

function showScreen(screen, saveHistory = true) {

    const currentScreen =
        document.querySelector(".screen:not(.hidden)");

    if (
        saveHistory &&
        currentScreen &&
        currentScreen !== screen
    ) {
        screenHistory.push(currentScreen);
    }

    [
        welcomeScreen,
        levelScreen,
        videoSelectScreen,
        lessonScreen
    ].forEach(screenItem => {

        if (screenItem) {
            screenItem.classList.add("hidden");
        }

    });

    if (screen) {
        screen.classList.remove("hidden");
    }

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}


/* =====================================================
   BACK
===================================================== */

function goBack() {

    if (screenHistory.length > 0) {

        const previousScreen = screenHistory.pop();

        showScreen(previousScreen, false);

    } else {

        showScreen(welcomeScreen, false);

    }
}


/* =====================================================
   HEADER BACK BUTTON
===================================================== */

const backBtn = document.getElementById("backBtn");

if (backBtn) {

    backBtn.addEventListener("click", function () {

        goBack();

    });

}


/* =====================================================
   START QUEST
===================================================== */

const startBtn = document.getElementById("startBtn");

if (startBtn) {

    startBtn.addEventListener("click", function () {

        showScreen(levelScreen);

    });

}


/* =====================================================
   LEVEL SELECTION
===================================================== */

document
    .querySelectorAll(".level-card:not(.coming-soon)")
    .forEach(button => {

        button.addEventListener("click", function () {

            showScreen(videoSelectScreen);

        });

    });


/* =====================================================
   VIDEO SELECTION
===================================================== */

document
    .querySelectorAll(".video-card")
    .forEach(button => {

        button.addEventListener("click", function () {

            showScreen(lessonScreen);

        });

    });


/* =====================================================
   INTERNAL BACK BUTTONS
===================================================== */

const backToLevels =
    document.getElementById("backToLevels");

if (backToLevels) {

    backToLevels.addEventListener("click", function () {

        goBack();

    });

}


const backToVideos =
    document.getElementById("backToVideos");

if (backToVideos) {

    backToVideos.addEventListener("click", function () {

        goBack();

    });

}


/* =====================================================
   ACCORDION
===================================================== */

const accordionHeaders =
    document.querySelectorAll(".accordion-header");


accordionHeaders.forEach(header => {

    header.addEventListener("click", function () {

        const section =
            this.closest(".accordion-section");

        if (!section) return;


        const content =
            section.querySelector(".accordion-content");

        const arrow =
            section.querySelector(".accordion-arrow");


        const isOpen =
            section.classList.contains("active");


        /* CLOSE */

        if (isOpen) {

            section.classList.remove("active");

            if (content) {
                content.style.maxHeight = null;
            }

            if (arrow) {
                arrow.textContent = "+";
            }

        }


        /* OPEN */

        else {

            section.classList.add("active");

            if (content) {
                content.style.maxHeight =
                    content.scrollHeight + "px";
            }

            if (arrow) {
                arrow.textContent = "−";
            }

        }

    });

});


/* =====================================================
   OPEN VIDEO SECTION BY DEFAULT
===================================================== */

const firstAccordion =
    document.querySelector(".accordion-section.active");


if (firstAccordion) {

    const firstContent =
        firstAccordion.querySelector(".accordion-content");

    if (firstContent) {

        firstContent.style.maxHeight =
            firstContent.scrollHeight + "px";

    }

}


/* =====================================================
   QUIZ
===================================================== */

let quizScore = 0;

const quizScoreElement =
    document.getElementById("quizScore");


const quizFeedback =
    document.getElementById("quizFeedback");


document
    .querySelectorAll(".answer-btn")
    .forEach(button => {

        button.addEventListener("click", function () {

            const questionCard =
                this.closest(".question-card");

            if (!questionCard) return;


            /* Don't allow another answer
               after the question is completed */

            if (
                questionCard.classList.contains(
                    "answered"
                )
            ) {
                return;
            }


            const allButtons =
                questionCard.querySelectorAll(
                    ".answer-btn"
                );


            const isCorrect =
                this.dataset.correct === "true";


            /* =================================================
               CORRECT
            ================================================= */

            if (isCorrect) {

                this.classList.add("correct");

                questionCard.classList.add(
                    "answered"
                );

                quizScore++;

                if (quizScoreElement) {

                    quizScoreElement.textContent =
                        quizScore;

                }


                if (quizFeedback) {

                    quizFeedback.className =
                        "feedback correct-feedback";

                    quizFeedback.textContent =
                        "✓ Correct! Great job!";

                }


                allButtons.forEach(btn => {

                    btn.disabled = true;

                });

            }


            /* =================================================
               WRONG
            ================================================= */

            else {

                this.classList.add("wrong");

                if (quizFeedback) {

                    quizFeedback.className =
                        "feedback wrong-feedback";

                    quizFeedback.textContent =
                        "✗ Not quite. Try again!";

                }


                /* Remove red after a short time */

                setTimeout(() => {

                    this.classList.remove("wrong");

                }, 900);

            }


            /* Keep accordion height correct */

            const section =
                questionCard.closest(
                    ".accordion-section"
                );

            if (section) {

                const content =
                    section.querySelector(
                        ".accordion-content"
                    );

                if (content) {

                    content.style.maxHeight =
                        content.scrollHeight + "px";

                }

            }

        });

    });


/* =====================================================
   VOCABULARY MATCHING
===================================================== */

let selectedMatch = null;

let matchedPairs = 0;

const totalPairs = 5;

const matchFeedback =
    document.getElementById("matchFeedback");


document
    .querySelectorAll(".match-item")
    .forEach(button => {

        button.addEventListener("click", function () {

            /* Already matched */

            if (
                this.classList.contains("matched")
            ) {
                return;
            }


            /* =================================================
               FIRST SELECTION
            ================================================= */

            if (!selectedMatch) {

                selectedMatch = this;

                this.classList.add(
                    "selected"
                );

                return;

            }


            /* =================================================
               SAME BUTTON
            ================================================= */

            if (selectedMatch === this) {

                this.classList.remove(
                    "selected"
                );

                selectedMatch = null;

                return;

            }


            /* =================================================
               SECOND SELECTION
            ================================================= */

            const first =
                selectedMatch;

            const second =
                this;


            const firstMatch =
                first.dataset.match;

            const secondMatch =
                second.dataset.match;


            /* =================================================
               CORRECT MATCH
            ================================================= */

            if (
                firstMatch === secondMatch
            ) {

                first.classList.remove(
                    "selected"
                );

                second.classList.remove(
                    "selected"
                );


                first.classList.add(
                    "matched"
                );

                second.classList.add(
                    "matched"
                );


                first.disabled = true;

                second.disabled = true;


                matchedPairs++;


                if (matchFeedback) {

                    matchFeedback.className =
                        "feedback correct-feedback";

                    matchFeedback.textContent =
                        "✓ Correct match!";

                }


                if (
                    matchedPairs === totalPairs
                ) {

                    setTimeout(() => {

                        if (matchFeedback) {

                            matchFeedback.className =
                                "feedback correct-feedback";

                            matchFeedback.textContent =
                                "🏆 Excellent! You matched everything!";

                        }

                    }, 400);

                }

            }


            /* =================================================
               WRONG MATCH
            ================================================= */

            else {

                first.classList.add(
                    "wrong"
                );

                second.classList.add(
                    "wrong"
                );


                if (matchFeedback) {

                    matchFeedback.className =
                        "feedback wrong-feedback";

                    matchFeedback.textContent =
                        "✗ Not a match. Try again!";

                }


                setTimeout(() => {

                    first.classList.remove(
                        "wrong"
                    );

                    second.classList.remove(
                        "wrong"
                    );

                }, 700);

            }


            selectedMatch = null;

        });

    });


/* =====================================================
   SPEAK / TYPE
===================================================== */

const speakAnswer =
    document.getElementById("speakAnswer");

const wordCount =
    document.getElementById("wordCount");

const clearAnswer =
    document.getElementById("clearAnswer");


if (speakAnswer && wordCount) {

    speakAnswer.addEventListener(
        "input",
        function () {

            const text =
                this.value.trim();


            if (!text) {

                wordCount.textContent =
                    "0 words";

                return;

            }


            const words =
                text.split(/\s+/).filter(Boolean);


            wordCount.textContent =
                words.length +
                (
                    words.length === 1
                        ? " word"
                        : " words"
                );

        }
    );

}


/* =====================================================
   CLEAR SPEAKING ANSWER
===================================================== */

if (clearAnswer && speakAnswer) {

    clearAnswer.addEventListener(
        "click",
        function () {

            speakAnswer.value = "";

            if (wordCount) {

                wordCount.textContent =
                    "0 words";

            }

            speakAnswer.focus();

        }
    );

}


/* =====================================================
   DARK / LIGHT MODE
===================================================== */

const themeBtn =
    document.getElementById("themeBtn");


function updateThemeButton() {

    if (!themeBtn) return;


    const lightMode =
        document.body.classList.contains(
            "light-mode"
        );


    if (lightMode) {

        themeBtn.textContent = "🌙";

        themeBtn.title =
            "Switch to dark mode";

    } else {

        themeBtn.textContent = "☀️";

        themeBtn.title =
            "Switch to light mode";

    }

}


/* =====================================================
   LOAD SAVED THEME
===================================================== */

const savedTheme =
    localStorage.getItem(
        "videoQuestTheme"
    );


if (savedTheme === "light") {

    document.body.classList.add(
        "light-mode"
    );

}


updateThemeButton();


/* =====================================================
   TOGGLE THEME
===================================================== */

if (themeBtn) {

    themeBtn.addEventListener(
        "click",
        function () {

            document.body.classList.toggle(
                "light-mode"
            );


            const isLight =
                document.body.classList.contains(
                    "light-mode"
                );


            localStorage.setItem(
                "videoQuestTheme",
                isLight
                    ? "light"
                    : "dark"
            );


            updateThemeButton();

        }
    );

}


/* =====================================================
   INITIAL SCREEN
===================================================== */

showScreen(
    welcomeScreen,
    false
);